
<?php $__env->startSection('title','SỬA TÁC GIẢ'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <form action="/admin/authors/edit/<?php echo e($author->id); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="PUT">

        <div class="form-group row">
            <label class="col-md-2">Tên tác giả :</label>
            <input type="text" name="name" value="<?php echo e($author->name); ?>" class="col-md-6 form-control">
        </div>
        <div class="form-group row">
            <label class="col-md-2">Ngày sinh :</label>
            <input type="date" name="dayBirth" value="<?php echo e($author->dayBirth); ?>" class="col-md-6 form-control">
        </div>
        <div class="form-group row">
            <label class="col-md-2">Mô tả :</label>
            <textarea name="description" cols="30" rows="10" class="form-control col-md-6"><?php echo e($author->description); ?></textarea>
        </div>
        <div class="form-group row">
            <label class="col-md-2">Ảnh tác giả :</label>
            <img class="col-md-2" src="<?php echo e($author->img); ?>" height="150px" alt="">
            <input type="file" name="img" class="form-control col-md-4">
        </div>
        <div class="row justify-content-center">
            <button class="btn btn-primary mr-2" type="submit">Gửi</button>
            <a type="button" class="btn btn-warning" onclick="window.history.go(-1); return false;">Hủy</a>
        </div>

    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\comic_website\resources\views/dashboard/authors/edit.blade.php ENDPATH**/ ?>