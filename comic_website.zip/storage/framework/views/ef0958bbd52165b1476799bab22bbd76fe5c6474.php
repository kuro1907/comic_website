
<?php $__env->startSection('title','QUẢN LÝ TÁC GIẢ'); ?>
<?php $__env->startSection('content'); ?>
<a class="btn btn-success" type="button" href="/admin/authors/create">Thêm tác giả</a>
<table class="table table-striped table-hover">
    <thead class=" table-bordered">
        <tr class="table-primary">
            <th>STT</th>
            <th>Tên tác giả</th>
            <th>Tác vụ</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$key); ?></td>
            <td><?php echo e($author->name); ?></td>
            <td><a type="button" class="btn btn-primary" href="/admin/authors/details/<?php echo e($author->id); ?>">Chi tiết</a>
                <a type="button" class="btn btn-outline-warning" href="/admin/authors/edit/<?php echo e($author->id); ?>">Sửa</a>
                <a type="submit" class="btn btn-outline-danger" href="/admin/authors/delete/<?php echo e($author->id); ?>" onClick="return confirm('Xoá tác giả <?php echo e($author->name); ?>?')">Xóa</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="col-md-12">
    <div class="row justify-content-center">
        <div class="pagination">
            <?php echo e($authors->appends(request()->query())); ?>

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\comic_website\resources\views/dashboard/authors/list.blade.php ENDPATH**/ ?>