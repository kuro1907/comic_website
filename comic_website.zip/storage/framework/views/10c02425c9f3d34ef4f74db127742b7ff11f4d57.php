
<?php $__env->startSection('title'); ?>
<title>Truyện <?php echo e($entities->name); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cover'); ?>
<div class="cover">
    <img src="<?php echo e($entities->cover_img); ?>" width="100%" height="450px" alt="">
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fruid top-20">
    <div class="col-md-12">
        <div class="row justify-content-md-center">
            <div class="col-md-3 col-sm-6 img-title">
                <img src="<?php echo e($entities->img); ?>" width="100%" height="100%" alt="">
            </div>
            <div class="col-md-8 col-sm-6">
                <h4>Tên truyện : <?php echo e($entities->name); ?></h4>
                <p><strong> Thể loại :</strong></p>
                <p><strong> Tác giả : </strong><?php echo e($author); ?></p>
                <p><strong> Mô tả :</strong> <?php echo e($entities->description); ?></p>

            </div>
        </div>
    </div>
</div>
<div class="container justify-content-md-center">
    <table class="table table-striped table-bordered top-20 table-hover">
        <thead class="thead-dark">
            <tr>
                <th scope="col">STT</th>
                <th scope="col">Tên chương</th>
                <th scope="col">Giờ cập nhật</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td scope="row"><?php echo e(++$key); ?></td>
                <td><a class="text-comic" href="">Chap <?php echo e($chapter->number); ?>: <?php echo e($chapter->name); ?></a></td>
                <td><?php echo e($chapter->dayRelease); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\casestudy3\comic-website\resources\views/comic/detail-comic.blade.php ENDPATH**/ ?>