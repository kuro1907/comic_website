
<?php $__env->startSection('title','SỬA THỂ LOẠI'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <form action="/admin/categories/edit/<?php echo e($category->id); ?>" method="post" class="needs-validation" novalidate>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="PUT">

        <div class="form-group row">
            <label class="col-md-2">Tên thể loại</label>
            <input type="text" name="name" class="col-md-6 form-control" value="<?php echo e($category->name); ?>" required>
            <div class="invalid-feedback">
                Vui lòng điền tên thể loại.
            </div>
        </div>
        <div class="row justify-content-center">
            <button class="btn btn-primary mr-2" type="submit">Gửi</button>
            <a type="button" class="btn btn-warning" onclick="window.history.go(-1); return false;">Hủy</a>
        </div>

    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\comic_website\resources\views/dashboard/categories/edit.blade.php ENDPATH**/ ?>