
<?php $__env->startSection('title','Truyện'); ?>
<?php $__env->startSection('cover'); ?>
<div class="col-md-12 top-50">
    <div class="row justify-content-md-center">
        <h3>Tên truyện</h3>
    </div>
    <div class="row justify-content-md-center">
        <a class="col-md-2 btn btn-dark" href="">Chap trước</a>
        <div class="col-md-5 ">
            <select class="form-control" onchange="window.location=this.value;">
                <option value="/doc-vo-luyen-dinh-phong-chuong-1109.html" selected>1</option>
                <option value="/doc-vo-luyen-dinh-phong-chuong-1109.html">2</option>
            </select>
        </div>
        <a class="col-md-2 btn btn-dark" href="">Chap sau</a>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content bottom-50 ">
    <div class="row justify-content-md-center">
        <img src="/storage/img/1200x628-100-2.jpg" alt="">
        <img src="/storage/img/1200x628-100-2.jpg" alt="">
        <img src="/storage/img/1200x628-100-2.jpg" alt="">
        <img src="/storage/img/1200x628-100-2.jpg" alt="">
        <img src="/storage/img/1200x628-100-2.jpg" alt="">
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\casestudy3\comic-website\resources\views/comic/chapter.blade.php ENDPATH**/ ?>