
<?php $__env->startSection('title','Trang chủ'); ?>
<?php $__env->startSection('cover'); ?>
<div class="cover">
    <div id="carouselExampleControls" class="carousel slide cover" data-ride="carousel">
        <div class="carousel-inner round">
            <?php $__currentLoopData = $comics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($comic->slide == 1): ?>

            <?php if($loop->first): ?>
            <div class="carousel-item active"><a href="/comic/<?php echo e($comic->id); ?>">
                    <?php else: ?>
                    <div class="carousel-item"><a href="/comic/<?php echo e($comic->id); ?>">
                            <?php endif; ?>
                            <div class="carousel-caption d-none d-md-block bg-cover">
                                <h4><?php echo e($comic->name); ?></h4>
                            </div>
                            <img class="d-block w-100 " src="<?php echo e($comic->cover_img); ?>" style="height:450px">
                        </a></div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>

    <div class="col-md-12">
        <div class="title-content col-md-12 bg-dark">
            <h3>TRUYỆN VỪA CẬP NHẬT</h3>
        </div>
        <div class="row justify-content-center">
            <?php for($i = 0; $i < count($comics); $i++): ?> <div class="col-lg-2 col-md-3 col-4 comic-item">
                <div class="img-comic">
                    <img src="<?php echo e($comics[$i]->img); ?>" style="height: 100%;width:100%" alt="">
                </div>
                <div class="name-comic"><a class="text-comic" href="/comic/<?php echo e($comics[$i]->id); ?>"><?php echo e($comics[$i]->name); ?></a></div>
                <div class="chapter"> <a class="text-comic" href="/comic/<?php echo e($comics[$i]->id); ?>/"> Chap <?php echo e($lastestChapterList[$i]->number); ?> - <?php echo e($lastestChapterList[$i]->name); ?> </a></div>

        </div>
        <?php endfor; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\casestudy3\comic-website\resources\views/index.blade.php ENDPATH**/ ?>