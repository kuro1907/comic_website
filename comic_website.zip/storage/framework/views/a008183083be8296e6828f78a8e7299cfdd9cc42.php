
<?php $__env->startSection('title','QUẢN LÝ TRUYỆN TRANH'); ?>
<?php $__env->startSection('content'); ?>
<a class="btn btn-success" type="button" href="/admin/comics/create">Thêm truyện</a>

<table class="table table-striped table-hover">
    <thead class=" table-bordered">
        <tr class="table-primary">
            <th>STT</th>
            <th>Tên truyện</th>
            <th>Slide chính</th>
            <th>Tác vụ</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $comics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$key); ?></td>
            <td><?php echo e($comic->name); ?></td>
            <td>
                <?php if($comic->slide == 1): ?>
                <p>Có</p>
                <?php else: ?>
                <p>Không</p>
                <?php endif; ?>
            </td>
            <td><a type="button" class="btn btn-primary" href="/admin/comics/details/<?php echo e($comic->id); ?>">Chi tiết</a>
                <a type="button" class="btn btn-outline-warning" href="/admin/comics/edit/<?php echo e($comic->id); ?>">Sửa</a>
                <a type="button" class="btn btn-outline-danger" href="/admin/comics/delete/<?php echo e($comic->id); ?>" onClick="return confirm('Xoá truyện <?php echo e($comic->name); ?>?')">Xóa</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="col-md-12">
    <div class="row justify-content-center">
        <div class="pagination">
            <?php echo e($comics->appends(request()->query())); ?>

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\comic_website\resources\views/dashboard/comics/list.blade.php ENDPATH**/ ?>