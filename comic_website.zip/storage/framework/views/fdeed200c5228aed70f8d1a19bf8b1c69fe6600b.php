
<?php $__env->startSection('title','THÊM NGƯỜI DÙNG'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <form action="/admin/users/create" method="post" class="needs-validation" novalidate>
        <?php echo csrf_field(); ?>
        <div class="form-group row">
            <label class="col-md-2">Tên đăng nhập:</label>
            <input type="text" name="username" class="col-md-6 form-control" required>
            <div class="invalid-feedback">
                Vui lòng điền tên đăng nhập.
            </div>
        </div>
        <div class="form-group row">
            <label class="col-md-2">Email:</label>
            <input type="email" name="email" class="col-md-6 form-control" required>
            <div class="invalid-feedback">
                Vui lòng điền email đầy đủ và đúng định dạng
            </div>
        </div>
        <div class="form-group row">
            <label class="col-md-2">Mật Khẩu:</label>
            <input type="password" name="password" class="col-md-6 form-control" required>
            <div class="invalid-feedback">
                Vui lòng điền mật khẩu.
            </div>
        </div>
        <div class="form-group row">
            <label class="col-md-2">Lặp lại mật khẩu:</label>
            <input type="password" name="password" class="col-md-6 form-control" required>
            <div class="invalid-feedback">
                Vui lòng nhập lại mật khẩu.
            </div>
        </div>
        <div class="form-group row">
            <label class="col-md-2">Quyền :</label>
            <select class="form-control col-md-6" name="role">
                <option value="user">Người dùng</option>
                <option value="admin">Quản trị</option>

            </select>
        </div>
        <div class="row justify-content-center">
            <button class="btn btn-primary mr-2" type="submit">Gửi</button>
            <a type="button" class="btn btn-warning" onclick="window.history.go(-1); return false;">Hủy</a>
        </div>

    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\comic_website\resources\views/dashboard/users/create.blade.php ENDPATH**/ ?>