
<?php $__env->startSection('title','QUẢN LÝ NGƯỜI DÙNG'); ?>
<?php $__env->startSection('content'); ?>
<a class="btn btn-success" type="button" href="/admin/users/create">Thêm người dùng</a>

<table class="table table-striped table-hover">
    <thead class=" table-bordered">
        <tr class="table-primary">
            <th>STT</th>
            <th>Tên tài khoản</th>
            <th>Email</th>
            <th>Tác vụ</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user_current): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$key); ?></td>
            <td><?php echo e($user_current->username); ?></td>
            <td><?php echo e($user_current->email); ?></td>
            <td>
                <a type="button" class="btn btn-primary" href="/admin/users/details/<?php echo e($user_current->id); ?>">Chi tiết</a>
                <a type="button" class="btn btn-outline-warning" href="/admin/users/edit/<?php echo e($user_current->id); ?>">Sửa</a>
                <a type="button" class="btn btn-outline-danger" href="/admin/users/delete/<?php echo e($user_current->id); ?>" onClick="return confirm('Xoá người dùng <?php echo e($user->name); ?>?')">Xóa</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="col-md-12">
    <div class="row justify-content-center">
        <div class="pagination">
            <?php echo e($users->appends(request()->query())); ?>

        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\comic_website\resources\views/dashboard/users/list.blade.php ENDPATH**/ ?>