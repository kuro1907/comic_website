
<?php $__env->startSection('title','Truyện'); ?>
<?php $__env->startSection('cover'); ?>
<div class="col-md-12 top-50">
    <div class="row justify-content-md-center">
        <h3><?php echo e($comic->name); ?> - Chap <?php echo e($chapter->number); ?>: <?php echo e($chapter->name); ?></h3>
    </div>
    <?php
    foreach($chapters as $key => $currentChapter) {
    if($currentChapter->id == $chapter->id) {
    $previous_chapter_id = $chapters[$key-1]->id;
    $next_chapter_id = $chapters[$key+1]->id;
    }
    }
    ?>
    <div class="row justify-content-md-center">
        <a class="col-md-2 btn btn-dark" href="/comic/<?php echo e($comic->id); ?>/chapter/<?php echo e($previous_chapter_id); ?>">Chap trước</a>
        <div class="col-md-5 ">
            <select class="form-control" onchange="window.location=this.value;">
                <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $currentChapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($currentChapter->id == $chapter->id): ?>
                <option value="/comic/<?php echo e($comic->id); ?>/chapter/<?php echo e($currentChapter->id); ?>" selected>Chap <?php echo e($currentChapter->number); ?> - <?php echo e($currentChapter->name); ?></option>
                <?php else: ?>
                <option value="/comic/<?php echo e($comic->id); ?>/chapter/<?php echo e($currentChapter->id); ?>">Chap <?php echo e($currentChapter->number); ?> - <?php echo e($currentChapter->name); ?></option>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <a class="col-md-2 btn btn-dark" href="/comic/<?php echo e($comic->id); ?>/chapter/<?php echo e($next_chapter_id); ?>">Chap sau</a>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content bottom-50 ">
    <div class="row justify-content-md-center">
        <?php echo $chapter->content; ?>

    </div>
</div>
<div class="container-fruid">
    <div class="col-md-12 top-50">

        <div class="row justify-content-md-center">
            <a class="col-md-2 btn btn-dark" href="">Chap trước</a>
            <div class="col-md-5 ">
                <select class="form-control" onchange="window.location=this.value;">
                    <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $currentChapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($currentChapter->id == $chapter->id): ?>
                    <option value="/comic/<?php echo e($comic->id); ?>/chapter/<?php echo e($currentChapter->id); ?>" selected>Chap <?php echo e($currentChapter->number); ?> - <?php echo e($currentChapter->name); ?></option>
                    <?php else: ?>
                    <option value="/comic/<?php echo e($comic->id); ?>/chapter/<?php echo e($currentChapter->id); ?>">Chap <?php echo e($currentChapter->number); ?> - <?php echo e($currentChapter->name); ?></option>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <a class="col-md-2 btn btn-dark" href="">Chap sau</a>

        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\comic_website\resources\views/comic/chapter.blade.php ENDPATH**/ ?>