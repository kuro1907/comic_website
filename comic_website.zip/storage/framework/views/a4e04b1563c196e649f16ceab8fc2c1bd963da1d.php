
<?php $__env->startSection('title','Danh sách truyện'); ?>
<?php $__env->startSection('cover'); ?>
<div class="cover">
    <img src="/storage/img/513535.jpg" width="100%" height="450px" alt="">
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="title-content col-md-12 bg-dark">
        <h3>DANH SÁCH TRUYỆN</h3>
    </div>
    <div class="row justify-content-center">
        <?php for($i = 0; $i < count($comics); $i++): ?> <div class="col-lg-2 col-md-3 col-4 comic-item">
            <div class="img-comic">
                <img src="<?php echo e($comics[$i]->img); ?>" style="height: 100%;width:100%" alt="">
            </div>
            <div class="name-comic text-center "><a class="text-comic" href="/comic/<?php echo e($comics[$i]->id); ?>"><?php echo e($comics[$i]->name); ?></a></div>
            <div class="chapter">
                <?php if(isset($lastestChapterList[$i])): ?>
                <a class="text-comic" style="color: #fff" href="/comic/<?php echo e($comics[$i]->id); ?>/chapter/<?php echo e($lastestChapterList[$i]->id); ?>"> Chap <?php echo e($lastestChapterList[$i]->number); ?> - <?php echo e($lastestChapterList[$i]->name); ?> </a>
                <?php else: ?>
                <a class=" text-comic" style="color: #fff" href="#">Chưa cập nhật</a>
                <?php endif; ?>
            </div>

    </div>
    <?php endfor; ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\comic_website\resources\views/listComic.blade.php ENDPATH**/ ?>