
<?php $__env->startSection('title','QUẢN LÝ THỂ LOẠI'); ?>
<?php $__env->startSection('content'); ?>
<a class="btn btn-success" type="button" href="/admin/categories/create">Thêm thể loại</a>

<table class="table table-striped table-hover">
    <thead class=" table-bordered">
        <tr class="table-primary">
            <th>STT</th>
            <th>Tên thể loại</th>
            <th>Tác vụ</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$key); ?></td>
            <td><?php echo e($category->name); ?></td>
            <td>
                <a type="button" class="btn btn-outline-warning" href="/admin/categories/edit/<?php echo e($category->id); ?>">Sửa</a>
                <a type="button" class="btn btn-outline-danger" onClick="return confirm('Xoá thể loại <?php echo e($category->name); ?>?')" href="/admin/categories/delete/<?php echo e($category->id); ?>">Xóa</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="col-md-12">
    <div class="row justify-content-center">
        <div class="pagination">
            <?php echo e($categories->appends(request()->query())); ?>

        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\comic_website\resources\views/dashboard/categories/list.blade.php ENDPATH**/ ?>