<?php

namespace App\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepository;

interface CategoryRepository extends BaseRepository
{
    public function getPaginate();
}
