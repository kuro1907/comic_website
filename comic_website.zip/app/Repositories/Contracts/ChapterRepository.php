<?php

namespace App\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepository;

interface ChapterRepository extends BaseRepository
{
}
